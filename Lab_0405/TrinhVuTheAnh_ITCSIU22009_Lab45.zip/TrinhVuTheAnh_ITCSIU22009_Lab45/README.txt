1. Open Terminal and Navigate to Folder "TrinhVuTheAnh_ITCSIU22009_Lab45"

2. Run these command in Terminal:
python sudoku.py --inputFile data/euler.txt
python sudoku.py --inputFile data/magictour.txt