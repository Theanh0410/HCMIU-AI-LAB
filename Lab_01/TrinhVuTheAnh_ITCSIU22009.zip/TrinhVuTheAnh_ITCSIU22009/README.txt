1. Copy Agents.py into search folder

2. Copy myLayout.lay into layouts folder

3. Run this command in Command Prompt:
python pacman.py --l myLayout --p ReflexAgent